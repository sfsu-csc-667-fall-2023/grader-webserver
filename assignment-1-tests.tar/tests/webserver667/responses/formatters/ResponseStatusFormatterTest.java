package tests.webserver667.responses.formatters;

/**
 * Does format return a correctly formatted response status line?
 */
public class ResponseStatusFormatterTest {

}
