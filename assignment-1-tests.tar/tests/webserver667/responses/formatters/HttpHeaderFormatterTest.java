package tests.webserver667.responses.formatters;

/**
 * Does format() return a correctly formatter headerline
 */
public class HttpHeaderFormatterTest {

}
