package tests.webserver667.responses;

/**
 * Given a string (and document root?), is the correct path generated
 * - note test isProtected and isScript!
 * 
 * 
 * - path: Path
 * - exists: boolean
 * - isProtected: boolean
 * - isScript: boolean
 * - queryString: String
 */
public class ResourceTest {

}
