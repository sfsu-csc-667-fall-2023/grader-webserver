package tests.webserver667.responses;

/**
 * Given a string (and document root?), is the correct path generated
 * - note test isProtected and isScript!
 */
public class ResourceTest {

}
