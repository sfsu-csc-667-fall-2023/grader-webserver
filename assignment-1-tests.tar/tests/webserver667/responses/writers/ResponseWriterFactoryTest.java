package tests.webserver667.responses.writers;

/**
 * For all inputs to create, are we creating an object of the correct
 * type?
 */
public class ResponseWriterFactoryTest {

}
