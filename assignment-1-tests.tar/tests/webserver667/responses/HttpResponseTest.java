package tests.webserver667.responses;

/**
 * HttpResponse is dao - need to test accessors and mutators
 */
public class HttpResponseTest {

}
