package tests.webserver667.exceptions;

public class ServerErrorExceptionTest {

}
